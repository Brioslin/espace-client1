- 👋 Hi, I’m @Brioslin
- 👀 I’m interested in procedural programming
- 🌱 I’m currently learning python
- 💞️ I’m looking to collaborate on IA development
- 📫 How to reach me brioslin@gmail.com
- 😄 Pronouns: ...
- ⚡ Fun fact: ...

<!---
Brioslin/Brioslin is a ✨ special ✨ repository because its `README.md` (this file) appears on your GitHub profile.
You can click the Preview link to take a look at your changes.
--->
