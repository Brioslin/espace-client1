<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
    <title>Document</title>
</head>
<body>
<img src="ressources/c.jpg" class="img-fluid" alt="..." style="width: 2000px; height: 400px;">
    <h1><marquee><b>BIENVENUE DANS NOTRE SITE DE CERTIFICATION DE NATIONALITE</b></marquee></h1>


  <header>
    <div class="container">
      <div class="logo">
        <img src="ressources/a.png" alt="Logo du ministère de l'Intérieur" style="width: 100px; height: 60px;"/>
      </div>
      <h1>Demande de certificat de nationalité</h1>
      <ul class="nav justify-content-end">
      <li class="nav-item">
      <a class="btn btn-primary" aria-current="page"  href="connexion.php">se connecter</a>
  </li>

</ul>
    </div>
  </header>

  <main>
    <div class="container">
      <div class="intro">
        <p>
          Vous pouvez effectuer une demande de certificat de nationalité en ligne en suivant les étapes suivantes :
        </p>
      </div>

      <div class="steps">
        <ol>
          <li>
            <span class="step-number">1</span>
            <span class="step-title">Remplir le formulaire de demande en ligne</span>
          </li>
          <li>
            <span class="step-number">2</span>
            <span class="step-title">Joindre les pièces justificatives demandées</span>
          </li>
          <li>
            <span class="step-number">3</span>
            <span class="step-title">Payer les frais de dossier</span>
          </li>
          <li>
            <span class="step-number">4</span>
            <span class="step-title">Envoyer votre demande</span>
          </li>
        </ol>
      </div>

      <div class="cta">
        <a href="inscription.php" class="btn">Commencer la demande</a>
      </div>
    </div>
  </main>

  <footer>
    <div class="container">
      <div class="copyright">
        <p>© Ministère de l'Intérieur</p>
      </div>
      <div class="contact">
        <p>
          <a href="#">Nous contacter</a>
        </p>
      </div>
    </div>
  </footer>

    <!--
    <div class="container">
      <input type="checkbox" id="flip">
      <div class="cover">
        
        <div class="back">
          <img class="backImg" src="images/backImage.jpg" alt="">
          <div class="text">
            <span class="text-1">Complete miles of journey <br> with one step.</span>
            <span class="text-2">Let's get started.</span>
          </div>
        </div>
      </div>
      
      <form action="#">
        <div class="form-content">
          <div class="login-form">
            <div class="title">Formulaire de connexion</div>
            <div class="input-boxes">
              <div class="input-box">
                <i class="fas fa-user"></i>
                <input type="text" placeholder="Entrer votre Login" required>
              </div>
              <div class="input-box">
                <i class="fas fa-envelope"></i>
                <input type="password" placeholder="Entrer votre mot de passe" required>
              </div>
              <div class="text"><a href="#">Mot de Passe Oublié?</a></div>
              <div class="button input-box">
                <input type="submit" value="Connexion">
              </div>
              <div class="text login-text">Tu n'as pas de Compte? <label for="flip">inscrivez vous</label></div>
            </div>
          </div>
          
          
            </div>
          </div>
        </div>
      </form>
    </div>
-->
  </body>
</html>







</body>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</html>