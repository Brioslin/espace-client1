<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Pieces a fournir </title>
</head>
<body>
    <header>
    <div class="block1">
        <p>COURS D'APPEL DU LITTORAL </p>
        <p> LITTORAL </p>
        <p> **********************</p><BR>
        <p> TRIBUNAL DE PREMIER INSTENCE  </p>
        <p> DU LITTORAL </p>
        <p> **********************</p><BR>
        <p>N°......................... CSO CA R/P T/O</P>    
    </div>
    <div class="bock2">
    <p> REPUBLIQUE DU CAMEROUN </p>
    <p> Paix-Travail-Patrie </p>
    </div>
    </header><br>
      <H1> <U>CERTIFICAT DE NATIONALITE CAMEROUNAISE</U> </H1>
      <form>
        <p>Nous soussigne. president de tribunal de Premiere Instance du Littoral.</p>
        <p>Vu les Articles 6 (a| a) et 42 de la loi n°68/LF /3 du 11 juin 1968 portant code de Nation Camerounaise: </p>
        <p>Vu la requete en date du</p><input type="text" required>
        <p>De M</p><input text="">
      </form>
</body>
</html>